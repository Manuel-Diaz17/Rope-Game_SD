echo "Transfering data to the RMIregistry node."
sshpass -f password ssh sd304@l040101-ws01.ua.pt 'mkdir -p test/RopeGame'
sshpass -f password ssh sd304@l040101-ws01.ua.pt 'rm -rf test/RopeGame/*'
sshpass -f password ssh sd304@l040101-ws01.ua.pt 'mkdir -p Public/classes/Interfaces'
sshpass -f password ssh sd304@l040101-ws01.ua.pt 'rm -rf Public/classes/Interfaces/*'
sshpass -f password scp dirRMIRegistry.zip sd304@l040101-ws01.ua.pt:test/RopeGame
echo "Decompressing data sent to the RMIregistry node."
sshpass -f password ssh sd304@l040101-ws01.ua.pt 'cd test/RopeGame ; unzip -uq dirRMIRegistry.zip'
sshpass -f password ssh sd304@l040101-ws01.ua.pt 'cd test/RopeGame/dirRMIRegistry ; cp Interfaces/*.class /home/sd304/Public/classes/Interfaces ; cp set_rmiregistry.sh /home/sd304; cp java.policy /home/sd304'
echo "Executing program at the RMIregistry node."
sshpass -f password ssh sd304@l040101-ws01.ua.pt 'sh set_rmiregistry.sh 22330'
