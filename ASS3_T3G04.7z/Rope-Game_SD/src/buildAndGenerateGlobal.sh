echo "Compiling source code."
find . -name "*.java" -print0 | xargs -0 javac -source 1.8 -target 1.8
echo "Distributing intermediate code to the different execution environments."


echo "  RMI registry"
rm -rf dirRMIRegistry/Interfaces dirRMIRegistry/Communication dirRMIRegistry/Others
mkdir -p dirRMIRegistry/Interfaces dirRMIRegistry/Communication dirRMIRegistry/Others
cp Interfaces/*.class dirRMIRegistry/Interfaces
cp Communication/*class dirRMIRegistry/Communication 
cp Others/*class dirRMIRegistry/Others
cp java.policy dirRMIRegistry

echo "  Register Remote Objects"
rm -rf dirRegistry/ServerSide ddirRegistry/Interfaces dirRegistry/Communication dirRegistry/Others
mkdir -p dirRegistry/ServerSide dirRegistry/ServerSide/Main dirRegistry/ServerSide/Objects dirRegistry/Interfaces dirRegistry/Communication dirRegistry/Others
cp ServerSide/Main/ServerRegisterRemoteObject.class dirRegistry/ServerSide/Main
cp ServerSide/Objects/RegisterRemoteObject.class dirRegistry/ServerSide/Objects
cp Interfaces/Register.class dirRegistry/Interfaces 
cp Communication/*class dirRegistry/Communication 
cp Others/*class dirRegistry/Others
cp java.policy dirRegistry

echo "  General Repository of Information"
rm -rf dirGeneralRepos/ServerSide dirGeneralRepos/ClientSide dirGeneralRepos/Interfaces dirGeneralRepos/Communication dirGeneralRepos/Others
mkdir -p dirGeneralRepos/ServerSide dirGeneralRepos/ServerSide/Main dirGeneralRepos/ServerSide/Objects dirGeneralRepos/Interfaces \
         dirGeneralRepos/ClientSide dirGeneralRepos/ClientSide/Entities dirGeneralRepos/Communication dirGeneralRepos/Others
cp ServerSide/Main/ServerGeneralInformationRepository.class dirGeneralRepos/ServerSide/Main
cp ServerSide/Objects/GeneralInformationRepository.class dirGeneralRepos/ServerSide/Objects
cp Interfaces/Register.class Interfaces/InterfaceGeneralInformationRepository.class dirGeneralRepos/Interfaces
cp ClientSide/Entities/Coach.class ClientSide/Entities/Contestant.class ClientSide/Entities/Referee.class dirGeneralRepos/ClientSide/Entities
cp Communication/*class dirGeneralRepos/Communication 
cp Others/*class dirGeneralRepos/Others


echo "  Playground"
rm -rf dirPlayground/ServerSide dirPlayground/ClientSide dirPlayground/Interfaces dirPlayground/Communication dirPlayground/Others
mkdir -p dirPlayground/ServerSide dirPlayground/ServerSide/Main dirPlayground/ServerSide/Objects dirPlayground/Interfaces \
         dirPlayground/ClientSide dirPlayground/ClientSide/Entities dirPlayground/Communication dirPlayground/Others
cp ServerSide/Main/ServerPlayground.class dirPlayground/ServerSide/Main
cp ServerSide/Objects/Playground.class dirPlayground/ServerSide/Objects
cp Interfaces/*.class dirPlayground/Interfaces
cp ClientSide/Entities/Coach.class ClientSide/Entities/Contestant.class ClientSide/Entities/Referee.class dirPlayground/ClientSide/Entities
cp Communication/*class dirPlayground/Communication 
cp Others/*class dirPlayground/Others


echo "  RefereeSite"
rm -rf dirRefereeSite/ServerSide dirRefereeSite/ClientSide dirRefereeSite/Interfaces dirRefereeSite/Communication dirRefereeSite/Others
mkdir -p dirRefereeSite/ServerSide dirRefereeSite/ServerSide/Main dirRefereeSite/ServerSide/Objects dirRefereeSite/Interfaces \
         dirRefereeSite/ClientSide dirRefereeSite/ClientSide/Entities dirRefereeSite/Communication dirRefereeSite/Others
cp ServerSide/Main/ServerRefereeSite.class dirRefereeSite/ServerSide/Main
cp ServerSide/Objects/RefereeSite.class dirRefereeSite/ServerSide/Objects
cp Interfaces/*.class dirRefereeSite/Interfaces
cp ClientSide/Entities/Coach.class ClientSide/Entities/Contestant.class ClientSide/Entities/Referee.class dirRefereeSite/ClientSide/Entities
cp Communication/*class dirRefereeSite/Communication 
cp Others/*class dirRefereeSite/Others


echo "  ContestantsBench"
rm -rf dirContestantsBench/ServerSide dirContestantsBench/ClientSide dirContestantsBench/Interfaces ContestantsBench/Communication ContestantsBench/Others
mkdir -p dirContestantsBench/ServerSide dirContestantsBench/ServerSide/Main dirContestantsBench/ServerSide/Objects dirContestantsBench/Interfaces \
         dirContestantsBench/ClientSide dirContestantsBench/ClientSide/Entities ContestantsBench/Communication ContestantsBench/Others
cp ServerSide/Main/ServerContestantsBench.class dirContestantsBench/ServerSide/Main
cp ServerSide/Objects/ContestantsBench.class dirContestantsBench/ServerSide/Objects
cp Interfaces/*.class dirContestantsBench/Interfaces
cp ClientSide/Entities/Coach.class ClientSide/Entities/Contestant.class ClientSide/Entities/Referee.class dirContestantsBench/ClientSide/Entities
cp Communication/*class ContestantsBench/Communication 
cp Others/*class ContestantsBench/Others



echo "  Coach"
rm -rf dirCoach/ServerSide dirCoach/ClientSide dirCoach/Interfaces dirCoach/Communication dirCoach/Others
mkdir -p dirCoach/ServerSide dirCoach/ServerSide/Main dirCoach/ClientSide dirCoach/ClientSide/Main dirCoach/ClientSide/Entities \
         dirCoach/Interfaces dirCoach/Communication dirCoach/Others
cp ClientSide/Main/ClientCoach.class dirCoach/ClientSide/Main
cp ClientSide/Entities/Coach.class dirCoach/ClientSide/Entities
cp Interfaces/*.class dirCoach/Interfaces
cp Communication/*class dirCoach/Communication 
cp Others/*class dirCoach/Others



echo "  Contestant"
rm -rf dirContestant/ServerSide dirContestant/ClientSide dirContestant/Interfaces dirContestant/Communication dirContestant/Others
mkdir -p dirContestant/ServerSide dirContestant/ServerSide/Main dirContestant/ClientSide dirContestant/ClientSide/Main dirContestant/ClientSide/Entities \
         dirContestant/Interfaces dirContestant/Communication dirContestant/Others
cp ClientSide/Main/ClientContestant.class dirContestant/ClientSide/Main
cp ClientSide/Entities/Contestant.class dirContestant/ClientSide/Entities
cp Interfaces/*.class dirContestant/Interfaces
cp Communication/*class dirContestant/Communication 
cp Others/*class dirContestant/Others



echo "  Referee"
rm -rf dirReferee/ServerSide dirReferee/ClientSide dirReferee/Interfaces dirReferee/Communication dirReferee/Others
mkdir -p dirReferee/ServerSide dirReferee/ServerSide/Main dirReferee/ClientSide dirReferee/ClientSide/Main dirReferee/ClientSide/Entities \
         dirReferee/Interfaces dirReferee/Communication dirReferee/Others
cp ClientSide/Main/ClientReferee.class dirReferee/ClientSide/Main
cp ClientSide/Entities/Referee.class dirReferee/ClientSide/Entities
cp Interfaces/*.class dirReferee/Interfaces
cp Communication/*class dirReferee/Communication 
cp Others/*class dirReferee/Others





echo "Compressing execution environments."
echo "  RMI registry"
rm -f  dirRMIRegistry.zip
zip -rq dirRMIRegistry.zip dirRMIRegistry


echo "  Register Remote Objects"
rm -f  dirRegistry.zip
zip -rq dirRegistry.zip dirRegistry

echo "  General Repository of Information"
rm -f  dirGeneralRepos.zip
zip -rq dirGeneralRepos.zip dirGeneralRepos

echo "  Playground"
rm -f  dirPlayground.zip
zip -rq dirReferee.zip dirReferee

echo "  ContestantsBench"
rm -f  dirContestantsBench.zip
zip -rq dirContestantsBench.zip dirContestantsBench

echo "  RefereeSite"
rm -f  dirRefereeSite.zip
zip -rq dirRefereeSite.zip dirRefereeSite




echo "  Coach"
rm -f  dirCoach.zip
zip -rq dirCoach.zip dirContestantsBench

echo "  Contestant"
rm -f  dirContestant.zip
zip -rq dirContestant.zip dirContestant

echo "  Referee"
rm -f  dirReferee.zip
zip -rq dirReferee.zip dirReferee



