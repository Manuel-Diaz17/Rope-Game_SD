echo "Transfering data to the Referee node."
sshpass -f password ssh sd304@l040101-ws08.ua.pt 'mkdir -p test/RopeGame'
sshpass -f password ssh sd304@l040101-ws08.ua.pt 'rm -rf test/RopeGame/*'
sshpass -f password scp src.zip sd304@l040101-ws08.ua.pt:test/RopeGame
echo "Decompressing data sent to the Referee node."
sshpass -f password ssh sd304@l040101-ws08.ua.pt 'cd test/RopeGame ; unzip -uq src.zip'
echo "Executing program"
sshpass -f password ssh sd304@l040101-ws08.ua.pt 'cd test/RopeGame/src; javac Game/Main.java; java Game/Main RF'

