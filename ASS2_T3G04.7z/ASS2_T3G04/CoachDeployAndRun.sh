echo "Transfering data to the Coach node."
sshpass -f password ssh sd304@l040101-ws09.ua.pt 'mkdir -p test/RopeGame'
sshpass -f password ssh sd304@l040101-ws09.ua.pt 'rm -rf test/RopeGame/*'
sshpass -f password scp src.zip sd304@l040101-ws09.ua.pt:test/RopeGame
echo "Decompressing data sent to the Coach node."
sshpass -f password ssh sd304@l040101-ws09.ua.pt 'cd test/RopeGame ; unzip -uq src.zip'
echo "Executing program"
sshpass -f password ssh sd304@l040101-ws09.ua.pt 'cd test/RopeGame/src;javac Game/Main.java; java Game/Main CH 1; java Game/Main CH 2'
echo "Client coaches deployed."
