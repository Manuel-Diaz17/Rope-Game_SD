xterm  -T "Playground" -hold -e "./PlaygroundDeployAndRun.sh" &
xterm  -T "ContestantsBench" -hold -e "./ContestantsBenchDeployAndRun.sh" &
xterm  -T "RefereeSite" -hold -e "./RefereeSiteDeployAndRun.sh" &
xterm  -T "GeneralRepository" -hold -e "./GeneralReposDeployAndRun.sh" &
sleep 3
xterm  -T "Coach" -hold -e "./CoachDeployAndRun.sh" &
xterm  -T "Referee" -hold -e "./RefereeDeployAndRun.sh" &
xterm  -T "Contestants" -hold -e "./ContestantsDeployAndRun.sh" &
