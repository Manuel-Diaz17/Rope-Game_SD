echo "Transfering data to the RefereeSite node."
sshpass -f password ssh sd304@l040101-ws05.ua.pt 'mkdir -p test/RopeGame'
sshpass -f password ssh sd304@l040101-ws05.ua.pt 'rm -rf test/RopeGame/*'
sshpass -f password scp src.zip sd304@l040101-ws05.ua.pt:test/RopeGame
echo "Decompressing data sent to the RefereeSite node."
sshpass -f password ssh sd304@l040101-ws05.ua.pt 'cd test/RopeGame ; unzip -uq src.zip'
echo "Executing program"
sshpass -f password ssh sd304@l040101-ws05.ua.pt 'cd test/RopeGame/src; javac Game/Main.java; java Game/Main RS'
